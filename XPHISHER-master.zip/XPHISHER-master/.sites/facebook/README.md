# Facebook Static Login Form (Full offline css and js)

## Author: [X PHANTOM PH4N7OM](https://github.com/XPH4N70M)

#### This is created for educational purposes demonstrating how phishing works.

### Use/Copy it legally and provide proper credit
