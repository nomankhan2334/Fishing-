# XPhisher

![Screenshot_20220519-161550_zoom](https://user-images.githubusercontent.com/70594016/169277722-f3c36452-57ae-4b55-b075-22ef21babad3.png)


#### Disclaimer

Any actions and or activities related to xphisher is solely your responsibility. The misuse of this toolkit can result in criminal charges brought against the persons in question. The contributors will not be held responsible in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

This toolkit contains materials that can be potentially damaging or dangerous for social media. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

This Tool is made for educational purposes only. Do not attempt to violate the law with anything contained here. If this is your intention, then Get the hell out of here!

It only demonstrates "how phishing works". You shall not misuse the information to gain unauthorized access to someones social media. However you may try out this at your own risk.

Tutorial:-
 

## Installation
Just, Clone this repository -
```bash
git clone https://github.com/XPH4N70M/XPHISHER.git
```
Change to cloned directory and run xphisher.sh -
```bash
cd XPHISHER 
```
![Screenshot_20220519-161949_zoom](https://user-images.githubusercontent.com/70594016/169277848-9385cd67-855a-4fba-9fd4-623082def278.png)

```bash
bash xphisher.sh
```
On first launch, It'll install the dependencies and that's it. xphisher is installed.

### Run on Docker
```bash
docker pull XPH4N70M/XPHISHER 
```
```bash
docker run --rm -it XPH4N70M/XPHISHER 
```
### Dependencies
xphisher requires following programs to run properly -
```bash
php
```
```bash
wget
```
```bash
curl
```
```bash
git
```
All the dependencies will be installed automatically when you run xphisher for the first time.

### Supported Platform : 
Termux, Ubuntu/Debian/Kali/Parrot, Arch Linux/Manjaro, Fedora

![PicsArt_05-26-10 54 23](https://user-images.githubusercontent.com/70594016/170422203-aec4bc41-c7ea-4ac5-a849-9494d6960c14.jpg)



............Join Us All https://bit.ly/3wiPUko ...............
